Other Included Features:
	Selection Box:
		Right Click and drag over the grid to create a selection (This is why no context menu was added as the Right Click would interfere with the selection code)
	
	Copy, Cut:
		This brings the contents of the grid to the internal clipboard of the program.
		Cut just zeros out the selection space.
		
	Paste:
		This Displays the Contents of Clipboard on the screen.
		Right Click will drag the selection around.
		Left Click will anchor the selection.
		
	Import:
		This acts similar to Load but it loads into the Clipboard,
		this also auto invokes the paste function.
		
	Export:
		This will invoke the save file dialog which will save what's in the clipboard.
		WARNING: IN ORDER TO EXPORT A SELECTION YOU HAVE TO COPY OR CUT IT FIRST!
		
	Play/Pause Button:
		The changing of the play pause button based on if the simulation is running or not.